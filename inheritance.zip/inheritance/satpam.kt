package inheritance

class satpam : karyawan() {

    var pos: String = ""

    fun menjaga(){
        println("Saya menjaga di $pos")
    }
}