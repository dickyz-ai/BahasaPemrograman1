package inheritance

open class orang {
    var nik: String = ""
    var nama: String = ""
    var alamat: String = ""

    fun perkenalan(){
        println("Hallo, nama saya $nama, alamat saya di $alamat")
    }
}